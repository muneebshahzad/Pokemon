//
//  PokedexApp.swift
//  Pokedex
//
//  Created by Michiel Spiritus on 13/03/2023.
//

import SwiftUI

@main
struct PokedexApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

